module.exports = {
    get: (req, res) => {
        res.send("User: Sarah");
    }
};